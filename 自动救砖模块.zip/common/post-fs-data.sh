#!/system/bin/sh
#特别鸣谢Magisk提供服务支持：by topjohnwu


MODDIR=${0%/*}
START_LOG=$MODDIR/Number_of_starts.log
export PATH="/product/bin:/apex/com.android.runtime/bin:/apex/com.android.art/bin:/system_ext/bin:/system/bin:/system/xbin:/odm/bin:/vendor/bin:/vendor/xbin:/data/user/0/com.gjzs.chongzhi.online/files/usr/busybox:/dev/P5TeaG/.magisk/busybox"
if [ -d "/data/adb/modules_update" ]; then
  mv /data/adb/modules_update /data/adb/lite_modules_update
  reboot
fi
if [ ! -d "/data/adb/modules" ]; then
  mkdir -p /data/adb/modules
fi
mount --bind /data/adb/lite_modules/ /data/adb/modules/

/system/bin/sh $MODDIR/Automatic_brick_rescue.sh
